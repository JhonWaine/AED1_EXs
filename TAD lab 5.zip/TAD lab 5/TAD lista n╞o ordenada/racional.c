#include "racional.h"
#include <stdio.h> 
#include <stdlib.h>

#define max 20 // tamanho máximo
struct lista{
    int no[max];
    int Fim;
};

/*
operação:
entrada:
pré condição:
processo:
saída:
pós condição:
*/
Lista cria_lista()
{
    Lista lst;
    lst = (Lista) malloc(sizeof(struct lista));
    
    if(lst!=NULL)
        lst->Fim=0;
    

    return lst;
} 

/*
operação:
entrada:
pré condição:
processo:
saída:
pós condição:
*/
int lista_vazia(Lista lst){
    if(lst->Fim==0)
        return 1; // Lista vazia
    else
        return 0; // Lista não vazia
}

/*
operação:
entrada:
pré condição:
processo:
saída:
pós condição:
*/
int lista_cheia (Lista lst){
    if (lst->Fim == max)
        return 1; // Lista cheia
    else
        return 0; // Lista não está cheia
}

/*
operação:
entrada:
pré condição:
processo:
saída:
pós condição:
*/

int insere_elem(Lista lst,int elem){
    if(lst ==NULL|| lista_cheia(lst)==1)
        return 0;
    
    lst -> no[lst->Fim] = elem;//insere elemento
    lst -> Fim++;// Avança o Fim
    return 1;
}

/*
operação:
entrada:
pré condição:
processo:
saída:
pós condição:
*/

int remove_elem(Lista lst,int elem){
    if(lst==NULL|| lista_vazia(lst)==1)
        return 0; // falha 
    int i,Aux = 0;
    
    // Pecorrimento até achar o elem ou final da lista
    while (Aux < lst ->Fim && lst ->no[Aux]!=elem)
    Aux++;

    if (Aux ==lst->Fim)// fim de lista (não existe elemento)
        return 0; // falha 

    //deslocamento à esq. do sucessor até o final da lista
    for (i= Aux + 1;i<lst->Fim;i++)
        lst -> no[i-1] = lst ->no[i];
    
    lst ->Fim --;// decremento do campo fim
    return 1; // sucesso

    
}

/*
operação:
entrada:
pré condição:
processo:
saída:
pós condição:
*/

int obtem_valor_elem(Lista lst){
    // Pecorrimento até o final da lista
    int Aux = 0;
    if(lst==NULL)
        return 0; // falha 
    while (Aux < lst ->Fim){

        printf("%d", lst -> no[Aux]);
        Aux++;
    }
    return 1;
}