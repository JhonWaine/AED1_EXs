#include <stdio.h>
#include <stdlib.h>
#include "racional.h"


int main()
{
    Lista lst;
    int i=0;  //variavel auxiliar do menu
    int elem; // elemento lido pelo usuario

    float d;
    Lista *Lista;

    inicio:
    while(i!=5){

        printf(" Menu:\n");
        printf(" digite 1, para iciciar uma lista:\n");
        printf(" digite 2, para iserir os elementos na lista:\n");
        printf(" digite 3, eliminar um elemento da lista:\n");
        printf(" digite 4, para imprimir a lsta :\n");
        printf(" digite 5, para fechar o programa:\n");

        scanf("%d", &i);
        setbuf(stdin, NULL);
    
        
        switch (i){
            case 1:
                lst = cria_lista();
                cria_lista();   
            
            break;
            
            case 2:
                printf(" digite o elemento a ser inserido:\n");
                scanf("%d",&elem);
                
                if  (1 == insere_elem(lst, elem));
                    printf("lista não alocada ou lista cheia\n");
                
                break;
            
            case 3:
                printf(" digite um elemento a ser removido da lista\n:");
                scanf("%d",&elem);
                
                if  (0 == remove_elem(lst,elem));
                    printf("falha ao remover elemento\n");

                break;
            case 4:
                printf(" A lista é a seguinte:\n");
                
                if (0==obtem_valor_elem(lst));
                    printf("lista não criada\n");
                break;
            
            case 5:
                goto inicio;
        }

    }  
   return 0;
}
