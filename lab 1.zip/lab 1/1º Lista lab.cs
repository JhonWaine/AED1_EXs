#include <stdio.h>
int main()
{
 float n1,n2,n3; //quantidade que cada jogador vai apostar
 float nt;//nota total
 float v;//valor do premio
 float pct;//porcemtagem
 float i; // variavel auxiliar
   
   printf(" digite o valor do premio:");
	scanf("%f",&n3);
   printf(" digite a quantidade que vc vai apostar:");
	scanf("%f",&n1);
   printf(" digite a quantidade que vc vai apostar:");
	scanf("%f",&n2);
   printf(" digite a quantidade que vc vai apostar:");
	scanf("%f",&v);
   nt=(n1+n2+n3);
     
     printf("o apostador 1 vai receber:%.2f \n",i=((n1/nt)*v));
     printf("o apostador 2 vai receber:%.2f \n",i=((n1/nt)*v));
     printf("o apostador 3 vai receber:%.2f \n",i=((n1/nt)*v));

 return 0;
}
// Todos os direitos resevados a Jhon Waine Mendes Gonçalves LTD