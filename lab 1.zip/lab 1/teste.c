#include <stdio.h>
int main()
{
    printf("\n");
    printf(" HELLO WORLD! ");
    printf("\n");
    return 0;
}