#include "lista.h"
#include <stdlib.h>
#include <string.h>

/*
Operação: cria_lista
    -Entrada: nenhuma
    -Pré-condição: nenhuma
    -Processo: criar uma lista e deixá-la no estado de vazia
    -Saída: endereço da lista criada
    -Pós-condição: nenhuma
*/
Lista cria_lista() {
    Lista lst = (Lista) malloc(sizeof(struct lista));
    if (lst != NULL)
        lst->fim = 0;
    return lst;
}

/*
Operação: lista_vazia
    -Entrada: endereço de uma lista
    -Pré-condição: lista ser válida
    -Processo: verifica se a lista está vazia
    -Saída: 1 se vazia ou 0 caso contrário
    -Pós-condição: nenhuma
*/
int lista_vazia(Lista lst) {
    if (lst == NULL)
        return 0;
    if (lst->fim == 0)
        return 1;
    else
        return 0;
}

/*
Operação: lista_cheia
    -Entrada: endereço de uma lista
    -Pré-condição: lista ser válida
    -Processo: verifica se a lista está cheia
    -Saída: 1 se cheia ou 0 caso contrário
    -Pós-condição: nenhuma
*/
int lista_cheia(Lista lst) {
    if (lst == NULL)
        return 0;
    if (lst->fim == MAX_ELEM)
        return 1;
    else
        return 0;
}

/*
Operação: insere_element
    -Entrada: endereço de uma lista e o elemento a ser inserido
    -Pré-condição: lista ser válida e não estar cheia
            elemento deve ser uma string válida e não exceder o tamanho máximo
    -Processo: inserir o elemento no final da lista
    -Saída: 1 - sucesso ou 0 - falha
    -Pós-condição: lista com um elemento a mais
*/

int insere_element(Lista lst, char elem) 
{
    // Trata lista vazia ou elemento ≥ último da lista
    if (lista_vazia(lst) == 1 || elem >= lst->no[lst->fim-1]) 
    {
        lst->no[lst->fim] = elem; // Insere no final 
    }
    else 
    {
        int i, aux = 0;
        while (elem >= lst->no[aux]) // Percorrimento
        {
            aux++;
            for (i = lst->fim; i > aux; i--) // Deslocamento
            {
                lst->no[i] = lst->no[i-1];
                lst->no[aux] = elem; // Inclui o elemento na lista
            }
        }
    }
    lst->fim++; // Avança o Fim
    return 1; // Sucesso
}

/*
Operação: remove_elem
    -Entrada: endereço de uma lista e o elemento a ser removido
    -Pré-condição: lista ser válida e não estar vazia
    -Processo: percorrer a lista até encontrar o elemento desejado ou chegar ao seu final
            Se o elemento existe, remova-o da lista
    -Saída: 1 - sucesso ou 0 - falha
    -Pós-condição: a lista de entrada com 1 elemento a menos
*/

int remove_elem(Lista lst, char elem) {
    if (lst == NULL || lista_vazia(lst))
        return 0;

    int i, j, aux; //counter

    for(i = 0; i < 1; i++) 
    {   
       
        if (elem == lst->no[i])
        {
            for( j = i+1; j < lst->fim -1; j++)
            {   

                lst[i] = lst[j];
                lst->fim--;
            }
        }
    }
   
    return 1;
}

/*
Operação: get_elem_pos
    -Entrada: endereço de uma lista, a posição do elemento desejado e o endereço do elemento a ser retornado
    -Pré-condição: lista ser válida e não estar vazia, posição deve ser válida
    -Processo: acessa o elemento na posição informada e o atribui à variável de retorno
    -Saída: 1 - sucesso ou 0 - falha
    -Pós-condição: nenhuma
*/
int get_elem_pos(Lista lst, int pos, char elem) {
    if (lst == NULL || lista_vazia(lst) || pos < 1 || pos > lst->fim)
        return 0;
    int i;
    elem = lst->no[pos-1];

    return 1;
}

/*
Operação: esvazia_lista
    -Entrada: endereço de uma lista
    -Pré-condição: lista ser válida
    -Processo: atribui 0 ao contador do fim da lista, tornando-a vazia
    -Saída: 1 - sucesso ou 0 - falha
    -Pós-condição: lista vazia
*/
int esvazia_lista(Lista lst) {
    if (lst == NULL)
        return 0;

    lst->fim = 0;
    return 1;
}

/*
Operação: apaga_lista
    -Entrada: endereço de uma lista
    -Pré-condição: lista deve existir
    -Processo: libera o espaço de memória alocado pela lista
    -Saída: 1 - sucesso ou 0 - falha
    -Pós-condição: a lista deixa de existir
*/
int apaga_lista(Lista *end_lst) {
    if (*end_lst == NULL)
        return 0;
    
    free(*end_lst);
    *end_lst = NULL;

    return 1;
}



/*
Operação: tamanho_lista
    -Entrada: endereço da lista
    -Pré-condição: lista deve ser válida
    -Processo: retorna o tamanho da lista
    -Saída: tamanho da lista ou -1 em caso de falha
    -Pós-condição: nenhuma
*/
int tamanho_lista(Lista lst) {
    if (lst == NULL)
        return -1;
    
    return lst->fim;
}




int remove_vogais(Lista lst) {
    if (lst == NULL || lista_vazia(lst))
        return 0;//falha lista vazia

    int i, j; //counter

    for(i = 0; i < lst->fim - 1; i++) 
    {   
       
        if (lst->no[i]=='A' || lst->no[i]=='E' || lst->no[i]=='I' || lst->no[i]=='O' ||lst->no[i]=='U' || lst->no[i]=='e' || lst->no[i]=='i'|| lst->no[i]=='o'|| lst->no[i]=='u'|| lst->no[i]=='U')
        {
            for( j = i+1; j < lst->fim -1; j++)
            {
                lst[i] = lst[j];
                lst->fim--;
            }
        }
    }
    return 1;
}



/*
Operação: concatena_listas
    -Entrada: endereço das listas a serem concatenadas e a lista resultante
    -Pré-condição: listas devem ser válidas e a soma de seus tamanhos não deve exceder o tamanho máximo
    -Processo: insere os elementos de lst1 e lst2 em lst3 de forma sequencial
    -Saída: 1 - sucesso ou 0 - falha
    -Pós-condição: lst3 contém o resultado da concatenação
*/
int concatena_listas(Lista lst1, Lista lst2, Lista lst3) {
    if (lst1 == NULL || lst2 == NULL || lst3 == NULL || (tamanho_lista(lst1) + tamanho_lista(lst2) > MAX_ELEM))
        return 0;

    esvazia_lista(lst3);
    char *elem;
    int i; //counters
    

    for(i = 0; i < tamanho_lista(lst1); i++)
    {
        *elem = lst1->no[i];
        insere_element(lst3, *elem);
    }
     for(i = 0; i < tamanho_lista(lst2); i++)
    {
        *elem = lst2->no[i];
        insere_element(lst3, *elem);
    }
  
    return 1;


}