#include <stdio.h>
#include "lista.h"


void imprime_lista(Lista lst);
void limpa_entrada();

int main () 
{
    
    Lista lst[3];
    lst[0] = NULL;
    lst[1] = NULL;
    lst[2] = cria_lista();
    int lista_atual = 0;
    int opcao = 0;
    int ret;
    int n;
    char elem;

    while (opcao != 11) {
        printf("Lista atual: L%d\n", lista_atual+1);
        printf("==================\n");
        printf("Escolha uma opcao:\n");
        printf("1 - Criar lista\n");
        printf("2 - Esvaziar lista\n");
        printf("3 - Imprimir lista\n");
        printf("4 - Inserir elementos\n");
        printf("5 - Remover um elemento\n");
        printf("6 - Apagar lista\n");
        printf("7 - \n");
        printf("8 - Remover vogais\n");
        printf("9 - \n");
        printf("10 - Concatenar listas L1 e L2\n");
        printf("11 - Encerrar\n");
        scanf("%d", &opcao);
        printf("\n");

        switch (opcao) 
        {
            case 1: 
            {
                if (lst[lista_atual] != NULL)
                    printf("Erro: Lista ja foi criada\n\n");
                else {
                    lst[lista_atual] = cria_lista();
                    if (lst[lista_atual] == NULL)
                        printf("Falha ao criar a lista\n\n");
                    else
                        printf("Lista criada com sucesso\n\n");
                        lista_atual++;
                }
                break;
            }

            case 2: 
            {
                ret = esvazia_lista(lst[lista_atual]);
                if (ret == 0)
                    printf("Erro: Lista nao inicializada\n\n");
                else
                    printf("Lista esvaziada com sucesso\n\n");
                break;
            }

            case 3: 
            {
                imprime_lista(lst[lista_atual]);
                break;
            }
            
            case 4: 
            {
                if (lst[lista_atual] == NULL) 
                {
                    printf("Erro: Lista nao inicializada\n\n");
                    break;
                }
                printf("Digite a quantidade de elementos: ");
                scanf("%d", &n);
                if (n > MAX_ELEM - lst[lista_atual]->fim || n < 1) 
                {
                    printf("Erro: quantidade excede capacidade da lista\n\n");
                    break;
                }
                printf("Digite os elementos\n");
                for (int i = 0; i < n; i++) 
                {
                    limpa_entrada();
                    scanf("%s", &elem);
                    ret = insere_element(lst[lista_atual], elem);
                    if (ret == 0) 
                    {
                        printf("Erro ao inserir elemento\n\n");
                        break;
                    }
                }
                printf("Elementos inseridos com sucesso\n\n");

                break;
            }

            case 5: 
            {
                if (lst[lista_atual] == NULL) 
                {
                    printf("Erro: Lista nao inicializada\n\n");
                    break;
                }

                printf("Digite o elemento para remocao\n");
                limpa_entrada();
                scanf("%s", &elem);
                printf("\n");

                ret = remove_elem(lst[lista_atual], elem);
                if (ret == 0)
                    printf("Erro: elemento nao encontrado ou lista vazia\n\n");
                else
                    printf("Elemento removido com sucesso\n\n");

                break;
            }

            case 6: 
            {
                ret = apaga_lista(&lst[lista_atual]);

                if (ret == 0)
                    printf("Erro: Lista nao inicializada\n\n");
                else
                    printf("Lista apagada com sucesso\n\n");

                break;
            }

            case 7: 
            {
                if (lst[lista_atual] == NULL) 
                {
                    printf("Erro: lista nao inicializada\n\n");
                    break;
                }
                printf("Digite a posicao para insercao\n");
                scanf("%d", &n);
                printf("Digite o elemento a ser inserido\n");
                limpa_entrada();
                scanf("%s", &elem);

                break;
            }

            case 8: 
            {
                if (lst[lista_atual] == NULL) {
                    printf("Erro: lista nao inicializada\n\n");
                    break;
                }
                //ret = remove_vogais(lst[lista_atual]);
                if (ret == 0)
                    printf("Falha ao remover o menor elemento. Verifique se a lista e valida e nao esta vazia\n\n");
                else
                    printf("Menor elemento removido com sucesso\n\n");
                
                break;
            }

            case 9: {
                //lista_atual = (lista_atual + 1) % 2;
                printf("Lista atual alterada\n\n");
                break;
            }

            case 10: {
                //ret = concatena_listas(lst[0], lst[1], lst[2]);
                if (ret == 0)
                    printf("Falha ao concatenar as listas. Verifique se seus tamanhos nao excedem o limite\n\n");
                else {
                    printf("Listas concatenadas com sucesso. Resultado:\n");
                    //imprime_lista(lst[2]);
                }
                break;
            }

            case 11: break;

            default: {
                printf("Opcao invalida\n\n");
            }
        }
    }

    apaga_lista(&lst[0]);
    apaga_lista(&lst[1]);
    apaga_lista(&lst[2]);

    return 0;
}

void imprime_lista(Lista lst) {
    if (lst == NULL) {
        printf("Erro: Lista nao inicializada\n\n");
        return;
    }
    if (lista_vazia(lst)) {
        printf("Lista vazia\n\n");
        return;
    }
    
    char elem;

    printf("Lista: {\n");
    for (int i = 1; get_elem_pos(lst, i, elem) == 1; i++) {
        printf("    %d: %s,\n", i, &elem);
    }
    printf("}\nA lista possui %d elementos\n\n", tamanho_lista(lst));
}

void limpa_entrada() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF)
        ;
}