
#ifndef LISTA_H
#define LISTA_H

#define MAX_ELEM 21

struct lista {
    char no[MAX_ELEM];
    int fim;
};
typedef struct lista *Lista;

Lista cria_lista();
int lista_vazia(Lista lst);
int lista_cheia(Lista lst);
int insere_element(Lista lst, char elem);
int remove_elem(Lista lst, char elem);
int get_elem_pos(Lista lst, int pos, char elem);
int esvazia_lista(Lista lst);
int apaga_lista(Lista *end_lst);
int tamanho_lista(Lista lst);
int remove_vogais(Lista lst);
int concatena_listas(Lista lst1, Lista lst2, Lista lst3);

#endif