#include <stdio.h>
#include <stdlib.h>
#include "racional.h"


int main()
{
    Lista lst;
    int i=0;  //variavel auxiliar do menu
    int elem; // elemento lido pelo usuario

    float d;
    Lista *Lista;

    inicio:
    while(i!=5){

        printf(" Menu:\n");
        printf(" digite 1, para iniciar uma lista:\n");
        printf(" digite 2, para iserir elementos como preço e nome na lista:\n");
        printf(" digite 3, eliminar um elemento da lista:\n");
        printf(" digite 4, para imprimir a lista:\n");
        printf(" digite 5, para fechar o programa:\n");

        scanf("%d", &i);
        setbuf(stdin, NULL);
    
        
        switch (i){
            case 1:
                lst = cria_lista();
                cria_lista();   
            
            break;
            
            case 2:
                printf(" digite o elemento a ser inserido:\n");
                scanf("%d",&elem);
                
                if  (1 == insere_elem(lst, elem));
                    printf("lista não alocada \n");
                
                break;
            
            case 3:
                printf(" digite um elemento a ser removido da lista:\n");
                scanf("%d",&elem);
                
                if  (0 == remove_elem(lst,elem));
                    printf("falha ao remover elemento\n");

                break;
            case 4:
                printf(" A lista é a seguinte:\n");
                
                if (1==obtem_valor_elem(lst));
                    printf(" Sucesso pai, vai mandar o projetinho? \n");
                break;
            
            case 5:
                goto inicio;
        }

    }  
   return 0;
}
