#ifndef RACIONAL_H_INCLUDED
#define RACIONAL_H_INCLUDED


typedef struct no * Lista;
Lista cria_lista();
int lista_vazia(Lista lst); 
int insere_elem(Lista *lst,int elem);
int remove_elem(Lista *lst,int elem);
int obtem_valor_elem(Lista *lst);

#endif