#include "racional.h"
#include <stdio.h> 
#include <stdlib.h>


struct no {
    int info ;
    struct no * prox;
};

Lista cria_lista()
{
    //aloca nó cabeçalho
    Lista cab;
    cab = (Lista) malloc(sizeof(struct no));
    //coloca lista no estado de vazia
    if(cab!=NULL){//SÓ se alocação não falhar
        cab -> prox= NULL;
        cab -> info =0;}//opcional de guarda quantidade                
    
    return cab;
} 


int lista_vazia(Lista lst){
    if(lst-> prox == NULL)
        return 1; // Lista vazia
    else
        return 0; // Lista não vazia
}





int insere_elem(Lista *lst,int elem){
    //aloca um novo nó
    Lista N =(Lista) malloc(sizeof(struct no));
    if(N == NULL){ return 0;} // falha nó naõ alocado
    //preenche os campos do novo nó
    N-> info = elem;//inser o conteúdo (valor do elem)
    // percorrimento da lista 
    Lista aux = *lst; // faz aux apontar para nío cabeçalho
    while (aux -> prox != NULL && aux -> prox ->info < elem)
    {
        aux =aux  -> prox; // Avança
    }
    // insere mo novo nó na lista
    N -> prox = aux -> prox;// aponta para o 1ºnó atual da lista
    aux -> prox = N;//faz o nó cabeçalho apontar para o novo nó
    (*lst) -> info++;//opcional para incrementar qtde de nós na lista   
    return 1;
}



int remove_elem(Lista *lst,int elem){
    if(lista_vazia (lst)==1)
        return 0; // falha 
    Lista aux = *lst;// ponteiro auxiliar para o nó cabeçalho
    // percorrimento até achar o elem ou final de lista 
    while (aux -> prox != NULL && aux -> prox -> info < elem)
        aux = aux -> prox;
    if (aux -> prox == NULL || aux -> prox -> info > elem) // Trata final de lista
        return 0; // falha
    // remove elemento da lista
    Lista aux2 = aux -> prox; // aponta nó a ser removido 
    aux -> prox = aux2 -> prox; //retira nó da lista 
    free(aux2); //libera memoria alocada
    (*lst)-> info --; // opcional: decrementa qtde de nós na lista
    return 1;     
}



int obtem_valor_elem(Lista *lst){
    if(lista_vazia (lst)==1)
        return 0; // falha 
    Lista aux = *lst;// ponteiro auxiliar para o nó cabeçalho
    // percorrimento até achar o final de lista 
    while (aux-> prox != NULL)
        aux = aux -> prox;
    
    return 1;
}

void tamanho_lista(Lista * lst){
    int a=0; // variavel que vai dar a qtde de nós na lista
    if(lista_vazia (lst)==1)
        printf ("0 elementos");
    
    Lista aux = *lst;// ponteiro auxiliar para o nó cabeçalho 
     while (aux-> prox != NULL){
        aux = aux -> prox;  
        a++;
    }
    printf("%d",a);
    
} 
void media_lista(Lista * lst){
    int a=0;
    int s=0 ;
    float m =0; // qtde de nos e soma dos elementos da lista
    if(lista_vazia (lst)==1){
        printf ("0 elementos");
    }
    Lista aux = *lst;// ponteiro auxiliar para o nó cabeçalho
    // percorrimento até achar o final de lista 
    while (aux-> prox != NULL){
        aux = aux -> prox;
        s= s + (*lst)->info;
        a++;       
    }
        
        m = s/a;  // média dos nós  
        printf (" a média dos elementos é: %.1f ",m);
}

int iguais(Lista *lst, Lista *lst2){
    if (lst2 == NULL){
        return -1;
    }
    
    Lista aux = lst;
    Lista aux2 = lst2;

    while (aux->prox != NULL && aux2->prox != NULL){
        if (aux->info != aux2->info){
            return 0;
        }
        aux = aux->prox;
        aux2 = aux2->prox;
    }

    return 1;  
}

Lista intercalar (Lista lst, Lista lst2){
    if (lista_vazia(lst) == 1||lista_vazia(lst2) == 1)
        return  NULL;
    
    Lista lst3 = (Lista) malloc(sizeof(struct no));

    if (lst3 == NULL){
        return NULL;
    }
    int inverte = 1;
    
    Lista aux = lst;
    Lista aux2 =lst2;

    Lista aux3 = lst3;

    aux3 -> info = aux -> info;
    aux3 -> prox = NULL;
    aux = aux -> prox;
    while (1)
    {
        if (inverte == 0)
        {
            if (aux != NULL){
                Lista lst5 =(Lista)malloc(sizeof(struct no));
                lst5 -> info =aux -> info;
                aux3 -> prox = lst5;
                aux3 = aux3 -> prox;
                aux-> prox = NULL;
                aux =aux -> prox;   
            }
             if (aux2 != NULL)
                inverte = 1;
            
        }
        else if (inverte == 1 ){
            if (aux2 != NULL){
                Lista lst4 = (Lista) malloc (sizeof(struct no));
                lst4 -> info =aux2 -> info;
                aux3 -> prox =lst4;
                aux3 = aux3 -> prox;
                aux3 -> prox = NULL;
                aux2 = aux2 -> prox;        
            }
            if (aux2 != NULL)
                inverte = 0;

        }
        if(aux == NULL && aux2 == NULL)
            break;
    }
     
    return lst3;
}

int remove_pares (Lista *lst){
    if(lista_vazia (*lst)) // lista estar vazia
        return 0; // falha

    Lista aux = (*lst); // aponta para p ultumo nóda lista 

    while (aux-> prox != (*lst)) // enquanto o proximo nó é diferente do ultimo nó 
    {
        if (aux -> prox -> info % 2 == 0)// se o procimo nó da for um número par
        {
            Lista  aux2 = aux -> prox; // receber o valor do procimo nó 
            aux -> prox = aux2 ->prox; // o procimo do nó atual ser mo procimo do procimo

            free (aux2); //libera o procimo nó
        }
        else 
            aux = aux -> prox; //recebe o valor do procimo nó
    }
    if ((*lst)-> info % 2 == 0) //verifica se o ultimo nó é par
    {
        if ((*lst) == (*lst) -> prox) // se triver só um elemento na lista 
        {
            aux = (*lst);
            *lst = NULL;
            free(aux); // libera a memoria desse elemento 
        }
        else 
        {
            Lista aux2 = *lst; // recebe o ultimo no da lista
            aux -> prox = (*lst) -> prox; // o procimo do penultimo para o primeiro nó da lista
            *lst= aux; // a lista agora aponta para o penultimo nó 
            free(aux2); // libera a memoria desse ultimo elemento 
        }
    }
    return 1;
}
Lista inverter (Lista lst){
    if (lista_vazia (lst)==1)
    return NULL;
    
    Lista lst2 = (Lista)malloc(sizeof(struct no));

    if (lst2 == NULL){
        return NULL;
    }
    lst2 -> info = lst -> info;
    lst2 -> prox = NULL;

    Lista aux = lst;
    Lista aux2 = lst2;

    while (aux -> prox != NULL){
        aux = aux -> prox;

        Lista lst3 = (Lista)malloc(sizeof(struct no)); 
        if (lst3 == NULL)
            return NULL;
        
        lst3 -> info = aux -> info;

        lst3 -> prox = aux2;
        lst2 = lst3;
        aux2 = lst2;
    }
    if (aux -> prox ==  NULL){
        Lista lst4 =(Lista)malloc(sizeof(struct no));
        if (lst4 == NULL)
            return NULL;
        
        lst4 -> info = aux -> info;
        lst4 -> prox = aux2;
    }
    return lst2;