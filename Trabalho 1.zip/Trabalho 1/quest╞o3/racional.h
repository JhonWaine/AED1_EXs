#ifndef RACIONAL_H_INCLUDED
#define RACIONAL_H_INCLUDED


typedef struct no * Lista;
Lista cria_lista();
int lista_vazia(Lista lst); 
int insere_elem(Lista *lst,int elem);
int remove_elem(Lista *lst,int elem);
int obtem_valor_elem(Lista *lst);
void tamanho_lista(Lista * lst);
void media_lista(Lista * lst);
void lista_igual(Lista * lst);
Lista intercalar (Lista lst, Lista lst2);
Lista inverter (Lista lst);


#endif