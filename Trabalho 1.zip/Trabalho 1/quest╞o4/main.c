#include <stdio.h>
#include <stdlib.h>
#include "racional.h"


int main()
{
    Lista lst[3];
    int i=0;  //variavel auxiliar do menu
    int l=0; //variavel auxiliar das listas
    int elem; // elemento lido pelo usuario

    float d;
    Lista *Lista;

    inicio:
    while(i!=12){

        printf(" Menu:\n");
        printf(" digite 1, para iniciar uma lista:\n");
        printf(" digite 2, para iserir elementos na lista:\n");
        printf(" digite 3, eliminar um elemento da lista:\n");
        printf(" digite 4, para imprimir a lista:\n");
        printf(" digite 5, para ver o tamanho da lista: \n");
        printf(" digite 6, para retorna apenas os números impares:\n");
        printf (" digite 7, para ver a média aritmetrica da lista:\n");
        printf (" digite 8, para fazer uma intercalação entre duas lista:\n");
        printf (" digite 9, para iverter a ordem da lista:\n");
        printf (" digite 10, para ver se as listas são iguais: \n");

        if (i==0){
            printf (" digite 11, para ir para 2º lista:\n");
        }
        else{
             printf (" digite 11, para ir para 1º lista:\n");
        }
        printf (" digite 12, para fechar o programa:");

        scanf("%d", &i);
        setbuf(stdin, NULL);
    
        
        switch (i){
            case 1:
                *lst = cria_lista();
                cria_lista();   
            
            break;
            
            case 2:
                printf(" digite o elemento a ser inserido:\n");
                scanf("%d",&elem);
                
                if  (1 == insere_elem(&lst, elem));
                    printf("lista não alocada \n");
                
                break;
            
            case 3:
                printf(" digite um elemento a ser removido da lista:\n");
                scanf("%d",&elem);
                
                if  (0 == remove_elem(&lst,elem));
                    printf("falha ao remover elemento\n");

                break;
            case 4:
                printf(" A lista é a seguinte:\n");
                
                if (1==obtem_valor_elem(&lst));
                    printf(" Sucesso pai, vai mandar o projetinho? \n");
                break;
            case 5:
                printf(" o tamanho da lista é: ");
                tamanho_lista(&lst);
                break;
            case 6:
                 printf("retorna ímpares");
                  remove_pares(&lst);
                break;
            case 7:
                printf("a média dos elementos da lista é:\n  ");
                media_lista(&lst);
                break;
            case 8:
                 lst[2] = intercala_lista(lst[0], lst[1]);
            
                break;
            case 9: 
                  inverter (&lst);
                break;
            case 10:
                if (iguais(lst[0], lst[1]) == -1){
                printf("\nNão foi possível comparar!\n");
            }
            else if (iguais(lst[0], lst[1]) == 0){
                printf("\n As listas não são iguais!\n");
                break;
            }
                
            case 11:
                if (i==0){
                    i=1;
                }
                else 
                    i=0;
                break;

            case 12:
                goto inicio;
        }

    }  
   return 0;
}
