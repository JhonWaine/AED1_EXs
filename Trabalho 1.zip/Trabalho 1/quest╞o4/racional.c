#include "racional.h"
#include <stdio.h> 
#include <stdlib.h>


struct no 
{
    int info;
    struct no *prox;
};


Lista cria_lista()
{
    // Aloca nó cabeçalho 
    Lista cab;
    cab =(Lista) malloc(sizeof(struct no));
    //Coloca lista no estado de vazia
    if (cab != NULL) // só se alocação não falhar 
    {
        cab -> prox = NULL;
        cab -> info = 0; // opcional: guarda qtde
    } 
    return cab;
}

int lista_vazia(Lista lst)
{
    if (lst -> prox == NULL)
        return 1; // lista vazia
    else
        return 0; // lista não vazia
}

int insere_ord(Lista *lst, int elem)
{
   // aloca um novo nó
   Lista N = (Lista)malloc(sizeof(struct no));
   if (N == NULL){ return 0; } // falha: nó não alocado
   N -> info = elem; // insere o conteúdo (valor do elem)

   // Percorimento da lista
   Lista aux = *lst; //Faz aux apontar para nó cabeçalho
   while (aux -> prox != NULL && aux -> prox -> info < elem)
        aux = aux -> prox; // Avança

    //Insere o novo nó na lista 
    N -> prox = aux -> prox;
    aux -> prox = N;
    
    (*lst)->info++;// opcional: incrementa qtde de nós na lista

    return 1;
}

int remove_ord (Lista *lst,int elem) 
{   if (lista_vazia(lst)==1)
        return 0; // falha
    Lista aux =*lst; //Ponteiro auxiliar para nó cabeçalho
    //percorrimento até final de lista, achar elem ou nó maior
    while (aux -> prox != NULL && aux -> prox < elem)
        aux = aux -> prox;
    
    if (aux -> prox == NULL || aux -> prox -> info > elem)
        return 0; // falha
    // remove elemento da lista 
    Lista aux2 = aux -> prox; //aponta nó a ser removido 
    aux -> prox = aux2 -> prox; //retira nó da lista
    free(aux2);// libera memoria alocada
    (*lst) -> info --; // opcional: decrementa qtde de nós na lista
    return 1;
}   


void tamanho_lista(Lista * lst){
    int a=0; // variavel que vai dar a qtde de nós na lista
    if(lista_vazia (lst)==1)
        printf ("0 elementos");
    
    Lista aux = *lst;// ponteiro auxiliar para o nó cabeçalho 
     while (aux-> prox != NULL){
        aux = aux -> prox;  
        a++;
    }
    a--;
    printf("%d",a);
    
}

int iguais(Lista *lst, Lista *lst2){
    if (lst2 == NULL){
        return -1;
    }
    
    Lista aux = lst;
    Lista aux2 = lst2;

    while (aux->prox != NULL && aux2->prox != NULL){
        if (aux->info != aux2->info){
            return 0;
        }
        aux = aux->prox;
        aux2 = aux2->prox;
    }

    return 1;  
}

Lista intercala_lista(Lista lst, Lista lst2){

    Lista lst = cria_lista();

    int i = 0;
    while (lst != NULL && lst2 != NULL) {
        if (i % 2 == 0) {
            insere_elem(&lst, lst->info);
            lst = lst->prox;
        } else {
            insere_elem(&lst, lst2->info);
            lst2 = lst2->prox;
        }
        i++;
    }
    Lista aux = lst == NULL ? lst2 : lst;

    while (aux != NULL) {
        insere_elem(&lst, aux->info);
        aux = aux->prox;
    }

    //Como a inserção é feita no inicio da lista, a lista vai ficar ao contrario depois de intercalar
    //Isso vai voltar a posição correta para a lista intercalada
    
    Lista intercalada = cria_lista();
    while (lst != NULL) {
        insere_elem(&intercalada, lst->info);
        lst = lst->prox;
    }

    return intercalada;
}
int remove_pares (Lista *lst){
    if(lista_vazia (*lst)) // lista estar vazia
        return 0; // falha

    Lista aux = (*lst); // aponta para p ultumo nóda lista 

    while (aux-> prox != (*lst)) // enquanto o proximo nó é diferente do ultimo nó 
    {
        if (aux -> prox -> info % 2 == 0)// se o procimo nó da for um número par
        {
            Lista  aux2 = aux -> prox; // receber o valor do procimo nó 
            aux -> prox = aux2 ->prox; // o procimo do nó atual ser mo procimo do procimo

            free (aux2); //libera o procimo nó
        }
        else 
            aux = aux -> prox; //recebe o valor do procimo nó
    }
    if ((*lst)-> info % 2 == 0) //verifica se o ultimo nó é par
    {
        if ((*lst) == (*lst) -> prox) // se triver só um elemento na lista 
        {
            aux = (*lst);
            *lst = NULL;
            free(aux); // libera a memoria desse elemento 
        }
        else 
        {
            Lista aux2 = *lst; // recebe o ultimo no da lista
            aux -> prox = (*lst) -> prox; // o procimo do penultimo para o primeiro nó da lista
            *lst= aux; // a lista agora aponta para o penultimo nó 
            free(aux2); // libera a memoria desse ultimo elemento 
        }
    }
    return 1;
}
void media_lista(Lista * lst){
    int a=0;
    int s=0 ;
    float m =0; // qtde de nos e soma dos elementos da lista
    if(lista_vazia (lst)==1){
        printf ("0 elementos");
    }
    *lst= (*lst) -> prox;
    Lista aux = *lst;// ponteiro auxiliar para o nó cabeçalho
    // percorrimento até achar o final de lista 
    while (aux-> prox != NULL){
        aux = aux -> prox;
        s= s + (*lst)->info;
        a++;       
    }
        
        m = s/a;  // média dos nós  
        printf (" a média dos elementos é: %.1f ",m);
}

Lista inverter (Lista lst){
    if (lista_vazia (lst)==1)
    return NULL;
    
    Lista lst2 = (Lista)malloc(sizeof(struct no));

    if (lst2 == NULL){
        return NULL;
    }
    lst2 -> info = lst -> info;
    lst2 -> prox = NULL;

    Lista aux = lst;
    Lista aux2 = lst2;

    while (aux -> prox != NULL){
        aux = aux -> prox;

        Lista lst3 = (Lista)malloc(sizeof(struct no)); 
        if (lst3 == NULL)
            return NULL;
        
        lst3 -> info = aux -> info;

        lst3 -> prox = aux2;
        lst2 = lst3;
        aux2 = lst2;
    }
    if (aux -> prox ==  NULL){
        Lista lst4 =(Lista)malloc(sizeof(struct no));
        if (lst4 == NULL)
            return NULL;
        
        lst4 -> info = aux -> info;
        lst4 -> prox = aux2;
    }
    return lst2;
}
